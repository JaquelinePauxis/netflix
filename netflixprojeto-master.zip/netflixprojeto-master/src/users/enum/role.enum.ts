export enum UserRole {
    USER = 'USER',
    ADMIN = 'ADMIN',
}