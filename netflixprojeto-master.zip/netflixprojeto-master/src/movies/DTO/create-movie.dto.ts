export class CreateMovieDto{
    name: string;
    year: Date;
    length: Date;
    storyline: string;
    image: string;
}